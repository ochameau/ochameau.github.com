
// By default, we don't want to display any window
pref("toolkit.defaultChromeURI", "");

