Components.utils.import("resource://gre/modules/XPCOMUtils.jsm");

function CommandLineHandler() {
}

CommandLineHandler.prototype.handle = function(aCmdLine){
try {

  var toggle = aCmdLine.handleFlag("ls", false);
  if (toggle) {
    dump("LS : \n");
    var list = aCmdLine.workingDirectory.directoryEntries;
    while(list.hasMoreElements()) {
      var file = list.getNext().QueryInterface(Components.interfaces.nsIFile);
      dump(" - "+file.leafName+"\n");
    }
    dump("\n");
  } 

  var filesize = aCmdLine.handleFlagWithParam("filesize", false);
  if (filesize) {
    dump("File size of : "+filesize+"\n");
    var file = aCmdLine.resolveFile(filesize);
    if (!file)
      return dump("Unable to find this file\n");
    dump("  "+file.fileSize+"\n");
  }

}
catch (e) {
  dump("Exception : \n" + e + "\n" +e.stack);
  throw Components.results.NS_ERROR_ABORT;
}
}
  
CommandLineHandler.prototype.helpInfo = "headless command line handler";
  
CommandLineHandler.prototype.classDescription = "Headless xulrunner Command Line Handler",
CommandLineHandler.prototype.contractID = "@mozilla.org/headless/app-clh;1",
CommandLineHandler.prototype.classID = Components.ID("{b3633310-adcc-11de-8a39-0800200c9a66}"),
CommandLineHandler.prototype.QueryInterface = XPCOMUtils.generateQI([Components.interfaces.nsICommandLineHandler]),
CommandLineHandler.prototype._xpcom_categories = [{ category: "command-line-handler", entry: "x-headless" }]


function NSGetModule(compMgr, fileSpec)
  XPCOMUtils.generateModule([CommandLineHandler]);

