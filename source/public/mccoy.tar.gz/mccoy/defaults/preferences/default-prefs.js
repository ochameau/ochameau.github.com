pref("toolkit.defaultChromeURI", "chrome://mccoy/content");
pref("toolkit.defaultChromeFeatures", "chrome,resizable,centerscreen,dialog=no");
pref("toolkit.singletonWindowType", "McCoy:Main");
pref("network.protocol-handler.expose-all", false);
pref("network.protocol-handler.warn-external-default", false);
pref("app.update.enabled", false);

pref("javascript.options.showInConsole", true);
pref("javascript.options.strict", true);
pref("browser.dom.window.dump.enabled", true);
