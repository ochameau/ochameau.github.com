pref("toolkit.defaultChromeURI", "");
