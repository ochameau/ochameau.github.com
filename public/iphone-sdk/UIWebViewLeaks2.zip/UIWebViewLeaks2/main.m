//
//  main.m
//  UIWebViewLeaks2
//
//  Created by UIWebViewLeaks2 on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"UIWebViewLeaks2AppDelegate");
    [pool release];
    return retVal;
}
