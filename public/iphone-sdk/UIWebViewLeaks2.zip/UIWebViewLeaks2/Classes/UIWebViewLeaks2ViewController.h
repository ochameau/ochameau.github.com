//
//  UIWebViewLeaks2ViewController.h
//  UIWebViewLeaks2
//
//  Created by UIWebViewLeaks2 on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIWebViewDeallocCheck.h"

@interface UIWebViewLeaks2ViewController : UIViewController {
  UIWebViewDeallocCheck *webview;
}

@end

