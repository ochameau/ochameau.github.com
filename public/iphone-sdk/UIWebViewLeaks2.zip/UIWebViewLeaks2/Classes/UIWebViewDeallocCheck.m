//
//  UIWebViewDeallocCheck.m
//  UIWebViewLeaks
//
//  Created by UIWebViewLeaks2 on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UIWebViewDeallocCheck.h"


@implementation UIWebViewDeallocCheck

- (void) dealloc
{
  NSLog(@"UIWebView dealloc called!");
  [super dealloc];
}

@end
