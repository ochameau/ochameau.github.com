//
//  UIWebViewLeaks2AppDelegate.h
//  UIWebViewLeaks2
//
//  Created by UIWebViewLeaks2 on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UIWebViewLeaks2ViewController;

@interface UIWebViewLeaks2AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UIWebViewLeaks2ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UIWebViewLeaks2ViewController *viewController;

@end

