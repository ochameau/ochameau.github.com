//
//  UIWebViewLeaks2ViewController.m
//  UIWebViewLeaks2
//
//  Created by UIWebViewLeaks2 on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UIWebViewLeaks2ViewController.h"

@implementation UIWebViewLeaks2ViewController


// Simply initialize the controller
- (void)loadView {
  self.view = [[UIView alloc] init];
  [self.view setFrame:[UIScreen mainScreen].bounds];
  
  [self performSelector:@selector(createWebview) withObject:nil afterDelay:5];
}

// Just instanciate one UIWebView and display it
- (void)createWebview {
  webview = [[UIWebViewDeallocCheck alloc] init];
  [webview setFrame:self.view.frame];
  webview.delegate = self;
  
  [self.view addSubview:webview];
  
  [self performSelector:@selector(loadHtmlPage) withObject:nil afterDelay:5];
}

// Open our local HTML file into the UIWebView
- (void)loadHtmlPage {
  [webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.google.com/"]]];
  
  [self performSelector:@selector(emptyWebview) withObject:nil afterDelay:40];
}

// Empty the webview to recover some memory
- (void)emptyWebview {
  [webview stringByEvaluatingJavaScriptFromString:@"document.body.innerHTML='';"];
  [self performSelector:@selector(releaseWebview) withObject:nil afterDelay:10];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
  [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"WebKitCacheModelPreferenceKey"];
  return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
  [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"WebKitCacheModelPreferenceKey"];
}


- (void)webViewDidFinishLoad:(UIWebView *)webView {
  [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"WebKitCacheModelPreferenceKey"];
}

// Finally release the UIWebView object
- (void)releaseWebview {
  [webview removeFromSuperview];
  webview.delegate = nil;
  [webview release];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {

}


- (void)dealloc {
    [super dealloc];
}

@end
