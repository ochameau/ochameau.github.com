//
//  MyProtocol.m
//  NativeBridge-non-buggy-protocol
//
//  Created by NativeBridge on 22/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MyProtocol.h"


@implementation MyProtocol

-(id)initWithRequest:(NSURLRequest *)request
      cachedResponse:(NSCachedURLResponse *)cachedResponse
                          client:(id <NSURLProtocolClient>)client
{
  // Instanciate JSON parser library
  if (!json)
    json = [ SBJSON new ];
  
  return [super initWithRequest:request cachedResponse:cachedResponse client:client];
}

+ (BOOL)canInitWithRequest:(NSURLRequest *)request
{
  BOOL canHandle = [[[request URL] scheme] isEqualToString:@"jscall"];
  return canHandle;
}

+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request
{
  return request;
}

-(void)stopLoading
{
}

static SBJSON *json = nil;
 
-(void)startLoading
{
  /*
  // in case of error, here is the code:
  [[self client] URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:0 userInfo:nil]];
  }*/
  //NSLog(@"Url=%@ parameterString=%@",url, [url query]);
  
  NSString *function = [[[self request] allHTTPHeaderFields] valueForKey:@"Call-Function"];
  hasCallback = [[[[self request] allHTTPHeaderFields] valueForKey:@"Call-Has-Callback"] isEqualToString:@"1"];
  NSString *argsAsString = [[[self request] allHTTPHeaderFields] valueForKey:@"Call-Args"];
  NSArray *args = (NSArray*)[json objectWithString:argsAsString error:nil];
  
  [self handleCall:function args:args];
  
}

- (void)returnResult:(id)arg, ...;
{
  if (!hasCallback) return;
  va_list argsList;
  NSMutableArray *resultArray = [[NSMutableArray alloc] init];
  
  if(arg != nil){
    [resultArray addObject:arg];
    va_start(argsList, arg);
    while((arg = va_arg(argsList, id)) != nil)
      [resultArray addObject:arg];
    va_end(argsList);
  }
  
  NSString *resultArrayString = [json stringWithObject:resultArray allowScalar:YES error:nil];
  NSData *data = [resultArrayString dataUsingEncoding:NSUTF8StringEncoding];
  
  NSURLResponse *response = [[NSURLResponse alloc] initWithURL: [[self request] URL]
                                                   MIMEType:nil
                                                   expectedContentLength:[data length]
                                                   textEncodingName:nil];
  [[self client] URLProtocol:self
                 didReceiveResponse:response
                 cacheStoragePolicy:NSURLCacheStorageNotAllowed];

  [[self client] URLProtocol:self didLoadData:data];
  [[self client] URLProtocolDidFinishLoading:self];
  
  [response release];
}


// Implements all you native function in this one, by matching 'functionName' and parsing 'args'
// Use 'callbackId' with 'returnResult' selector when you get some results to send back to javascript
- (void)handleCall:(NSString*)functionName args:(NSArray*)args
{
  if ([functionName isEqualToString:@"setBackgroundColor"]) {
    
    if ([args count]!=3) {
      NSLog(@"setBackgroundColor wait exactly 3 arguments!");
      return;
    }
    NSNumber *red = (NSNumber*)[args objectAtIndex:0];
    NSNumber *green = (NSNumber*)[args objectAtIndex:1];
    NSNumber *blue = (NSNumber*)[args objectAtIndex:2];
    //NSLog(@"setBackgroundColor(%@,%@,%@)",red,green,blue);
    
    // Try to each our webview to change its background color ...
    [((UIView*)[[UIApplication sharedApplication].keyWindow.subviews objectAtIndex:0]) performSelectorOnMainThread:@selector(setBackgroundColor:) withObject:[UIColor colorWithRed:[red floatValue] green:[green floatValue] blue:[blue floatValue] alpha:1.0] waitUntilDone:NO];
    
    [self returnResult:nil];
    
  } else if ([functionName isEqualToString:@"prompt"]) {
    
    if ([args count]!=1) {
      NSLog(@"prompt wait exactly one argument!");
      return;
    }
        
    NSString *message = (NSString*)[args objectAtIndex:0];
    
    UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil] autorelease];
    [alert show];
    
  } else {
    NSLog(@"Unimplemented method '%@'",functionName);
  }
}

// Just one example with AlertView that show how to return asynchronous results
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
  
  NSLog(@"prompt result : %d",buttonIndex);
  
  BOOL result = buttonIndex==1?YES:NO;
  [self returnResult:[NSNumber numberWithBool:result],nil];
  
}

@end
