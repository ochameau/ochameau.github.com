//
//  NativeBridgeAppDelegate.m
//  NativeBridge
//
//  Created by NativeBridge on 14/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "NativeBridgeAppDelegate.h"
#import "NativeBridgeViewController.h"

#import "MyProtocol.h"

@implementation NativeBridgeAppDelegate

@synthesize window;
@synthesize viewController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after application launch.
    
    [NSURLProtocol registerClass:[MyProtocol class]];
    
    // Add the view controller's view to the window and display.
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];

    return YES;
}

  



- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
    [NSURLProtocol unregisterClass:[MyProtocol class]];
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
