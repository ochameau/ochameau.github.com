//
//  MyProtocol.h
//  NativeBridge-non-buggy-protocol
//
//  Created by NativeBridge on 22/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SBJSON.h"

@interface MyProtocol : NSURLProtocol {
  BOOL hasCallback;
  SBJSON *json;
}
@end
