
var NativeBridge = {
  
  // Use this in javascript to request native objective-c code
  // functionName : string (I think the name is explicit :p)
  // args : array of arguments
  // callback : function with n-arguments that is going to be called when the native code returned
  call : function call(functionName, args, callback) {
    
    var hasCallback = callback && typeof callback == "function";
    var async = true;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "jscall://call.fr", async);
    if (hasCallback && async) {
      xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
          var resultArray = JSON.parse(xmlhttp.responseText);
          callback.apply(null,resultArray);
        }
      }
    }
    xmlhttp.setRequestHeader("Call-Function",functionName);
    xmlhttp.setRequestHeader("Call-Has-Callback",hasCallback?"1":"0");
    xmlhttp.setRequestHeader("Call-Args", JSON.stringify(args));
    xmlhttp.send(null);    
    if (hasCallback && !async) {
      var resultArray = JSON.parse(xmlhttp.responseText);
      callback.apply(null,resultArray);
    }
    
  }

};


