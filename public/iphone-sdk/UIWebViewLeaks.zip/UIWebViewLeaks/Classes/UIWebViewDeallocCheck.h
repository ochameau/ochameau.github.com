//
//  UIWebViewDeallocCheck.h
//  UIWebViewLeaks
//
//  Created by UIWebViewLeaks on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


@interface UIWebViewDeallocCheck : UIWebView {

}

@end
