//
//  UIWebViewLeaksViewController.m
//  UIWebViewLeaks
//
//  Created by UIWebViewLeaks on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UIWebViewLeaksViewController.h"

@implementation UIWebViewLeaksViewController


// Simply initialize the controller
- (void)loadView {
  self.view = [[UIView alloc] init];
  [self.view setFrame:[UIScreen mainScreen].bounds];
  
  [self performSelector:@selector(createWebview) withObject:nil afterDelay:7];
}

// Just instanciate one UIWebView and display it
- (void)createWebview {
  webview = [[UIWebViewDeallocCheck alloc] init];
  [webview setFrame:self.view.frame];
  
  [self.view addSubview:webview];
  
  [self performSelector:@selector(loadHtmlPage) withObject:nil afterDelay:5];
}

// Open our local HTML file into the UIWebView
- (void)loadHtmlPage {
  NSString *path = [[NSBundle mainBundle] pathForResource:@"test" ofType:@"html"];
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]];
  [webview loadRequest:request];
  
  [self performSelector:@selector(emptyWebview) withObject:nil afterDelay:60];
}

// Empty the webview to recover some memory
- (void)emptyWebview {
  [webview stringByEvaluatingJavaScriptFromString:@"document.body.innerHTML='';"];
  [self performSelector:@selector(releaseWebview) withObject:nil afterDelay:10];
}

// Finally release the UIWebView object
- (void)releaseWebview {
  [webview removeFromSuperview];
  [webview release];
}


- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {

}


- (void)dealloc {
    [super dealloc];
}

@end
