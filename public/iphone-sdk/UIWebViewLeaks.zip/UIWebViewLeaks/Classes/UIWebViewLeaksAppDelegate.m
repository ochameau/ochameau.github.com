//
//  UIWebViewLeaksAppDelegate.m
//  UIWebViewLeaks
//
//  Created by UIWebViewLeaks on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UIWebViewLeaksAppDelegate.h"
#import "UIWebViewLeaksViewController.h"

@implementation UIWebViewLeaksAppDelegate

@synthesize window;
@synthesize viewController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
  NSLog(@"WebKitCacheModelPreferenceKey = %d (0=no cache, no leaks, 1=cache and huge leaks)",[[NSUserDefaults standardUserDefaults] integerForKey:@"WebKitCacheModelPreferenceKey"]);
  
  // Disable cache which causes these huge leaks
  //[[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"WebKitCacheModelPreferenceKey"];
  
  // Enable it and leaks!!
  //[[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"WebKitCacheModelPreferenceKey"];
  
  window = [[UIWindow alloc] init];
  viewController = [[UIWebViewLeaksViewController alloc] init];
  [viewController loadView];
  
  [window setFrame:[UIScreen mainScreen].applicationFrame];
  
  [window addSubview:viewController.view];
  [window makeKeyAndVisible];

  return YES;
}



#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
