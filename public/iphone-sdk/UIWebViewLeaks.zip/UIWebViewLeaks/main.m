//
//  main.m
//  UIWebViewLeaks
//
//  Created by UIWebViewLeaks on 04/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"UIWebViewLeaksAppDelegate");
    [pool release];
    return retVal;
}
